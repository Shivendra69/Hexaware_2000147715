package model;

import java.util.Date;

public class Payment {
    private int paymentId;
    private int studentId;
    private double amount;
    private Date paymentDate;
    private Student student;

    public Payment(int paymentId, int studentId, double amount, Date paymentDate) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Payment amount must be greater than zero.");
        }
        if (paymentDate == null) {
            throw new PaymentValidationException("Payment date cannot be null.");
        }
        this.paymentId = paymentId;
        this.studentId = studentId;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Payment amount must be greater than zero.");
        }
        this.amount = amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) throws PaymentValidationException {
        if (paymentDate == null) {
            throw new PaymentValidationException("Payment date cannot be null.");
        }
        this.paymentDate = paymentDate;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public double getPaymentAmount() {
        return amount;
    }

    public void displayPaymentInfo() {
        System.out.println("Payment ID: " + paymentId);
        System.out.println("Student ID: " + studentId);
        System.out.println("Payment Amount: " + amount);
        System.out.println("Payment Date: " + paymentDate);
    }
}